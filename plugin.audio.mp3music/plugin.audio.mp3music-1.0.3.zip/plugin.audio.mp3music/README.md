![MP3 Music logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack-matrix/blob/master/plugin.audio.mp3music/resources/icon.png)

plugin.audio.mp3music
======================

Kodi Addon for streaming and downloading music. Browse the latest album releases including compilations by genre. Search or download your favourite artist, album or song. Show artist information and download icons and fanart.