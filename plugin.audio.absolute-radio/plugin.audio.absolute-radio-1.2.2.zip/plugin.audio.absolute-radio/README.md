![Absolute Radio logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack-matrix/blob/master/plugin.audio.absolute-radio/resources/icon.png)

plugin.audio.absolute-radio
===========================

Kodi Addon for listening to Absolute Radio live broadcasts

Absolute Radio is one of the UK's Independent National Radio stations. The station is based in London and plays popular rock music broadcasting on medium wave and DAB across the UK (105.8 FM in London and 105.2 FM in the West Midlands). It is also available in other parts of the world via satellite, cable, and on the Internet.