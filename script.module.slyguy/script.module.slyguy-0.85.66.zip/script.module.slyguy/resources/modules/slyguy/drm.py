# legacy for addons using these
from slyguy.settings import is_wv_secure, req_wv_level, req_hdcp_level, widevine_level, hdcp_level, set_drm_level, HDCP_2_2, WV_L1
