![System Info logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack-matrix/blob/master/script.system-info/resources/icon.png)

script.system-info
==================

Displays information about Software, CPU, Hardware, Memory, Storage, Addons Installed and Network settings. Including connections to previous networks along with WiFi passphrase.
