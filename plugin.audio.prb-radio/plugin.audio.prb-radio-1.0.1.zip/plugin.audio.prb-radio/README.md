![PRB Radio logo](https://github.com/PhantomRaspberryBlower/plugin.audio.prb-radio/blob/master/resources/icon.png)

plugin.audio.prb-radio
======================

Kodi Addon for listening to PRB Radio live broadcasts

PRB Radio is an online radio show produced by Phantom Raspberry Blower offering Blues, Gospel, Jazz, Soul, Reggae, Funk and Hip-Hop to music lovers who get sick of hearing the same old songs played over and over again by commercial radio stations.