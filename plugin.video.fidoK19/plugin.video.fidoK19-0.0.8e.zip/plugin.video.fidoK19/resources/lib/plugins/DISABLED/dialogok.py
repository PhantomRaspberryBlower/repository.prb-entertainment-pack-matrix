

def main():
	import xbmcgui
	xbmcgui.Dialog().ok('DialogOk', 'press Ok')

if __name__ == '__main__':
	main()