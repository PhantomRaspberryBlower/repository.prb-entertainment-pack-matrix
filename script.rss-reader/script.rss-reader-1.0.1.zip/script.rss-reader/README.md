![RSS Reader logo](https://github.com/PhantomRaspberryBlower/repository.prb-entertainment-pack-matrix/blob/master/script.rss-reader/resources/icon.png)

script.rss-reader
=================

Kodi Addon for showing subscribed rss feeds

RSS (Rich Site Summary; often called Really Simple Syndication) is a type of web feed which allows users to access updates to online content. Websites usually use RSS feeds to publish frequently updated information, such as blog entries, news headlines, audio, video. An RSS document (called "feed") includes full or summarized text, and metadata, like publishing date and author's name.